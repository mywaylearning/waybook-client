/*timeline handler schema 
 
  pull every data point (commitments) and store them. collate the tags you've received so you know how many rows to draw (up to 8 on screen at any one time)
  
  draw the timeline
  draw the date crossbars
  figure out what section of the timeline is visible
  scan the list of commitments, draw the ones that should be visible plotted against the correct tags at the right point on the timeline
  each time the user swipes/mousewheels, re-draw the commitments that should be visible
*/


var canvas = new fabric.Canvas('timeline');
canvas.width = 1024;
canvas.height = 768;
var tags = [];
var commitments = [];
var time1 = 0;
var time2 = 0;
var timegap = 518400;
var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
//86400 seconds in a day
//604800 seconds in a week
//2592000 seconds in a month
//31536000 seconds in a year
var columncount = 0;
$(function(){

  /*
  var poly1 = new fabric.Polyline([
    {x:200, y:100},{x:250, y:100},{x:175, y:500},{x:100, y:500}], {fill:'#eeeeee', left:100, top:100});
  var poly2 = new fabric.Polyline([
    {x:250, y:100},{x:300, y:100},{x:250, y:500},{x:175, y:500}], {fill:'#eeddff', left:175, top:100});	
  var poly3 = new fabric.Polyline([
    {x:300, y:100},{x:350, y:100},{x:325, y:500},{x:250, y:500}], {fill:'#ffeedd', left:250, top:100});	
  var poly4 = new fabric.Polyline([
    {x:350, y:100},{x:400, y:100},{x:400, y:500},{x:325, y:500}], {fill:'#eeffee', left:325, top:100});
  var poly5 = new fabric.Polyline([
    {x:400, y:100},{x:450, y:100},{x:475, y:500},{x:400, y:500}], {fill:'#dddddd', left:400, top:100});
  var poly6 = new fabric.Polyline([
    {x:450, y:100},{x:500, y:100},{x:550, y:500},{x:475, y:500}], {fill:'#ddeeff', left:450, top:100});
  var poly7 = new fabric.Polyline([
    {x:500, y:100},{x:550, y:100},{x:625, y:500},{x:550, y:500}], {fill:'#ffddee', left:500, top:100});	
  var poly8 = new fabric.Polyline([
    {x:550, y:100},{x:600, y:100},{x:700, y:500},{x:625, y:500}], {fill:'#ccffee', left:550, top:100});
  canvas.add(poly1, poly2, poly3, poly4, poly5, poly6, poly7, poly8);*/
  
  $.getJSON("testdata.json").done(function(data){
    $.each(data, function(){
		//alert(this);
		var k = this.Tags;
		//alert(k);
		$.each(k, function(){
		  //alert(this);
		  //if(this.toString() === "Tag1"){alert('hit');}
		  if($.inArray(this.toString(), tags) === -1){ tags.push(this.toString()); }
		 });
		 //alert(tags.length);
		 
		 commitments.push(this);
    });
	
	drawTimeline();
  });
  

  
});

function drawTimeline(){
    var tagcount = tags.length;
	//alert (tagcount);
	
	/*
	if (tagcount <= 7){
	  columncount = tagcount + 1;
	  if ((tagcount % 2) === 0){
	    //even
	    var poly1 = new fabric.Polyline(
		  [{x:375, y:100}, {x:425, y:100}, {x:450, y:700}, {x:350, y:700}], {fill:'#cccccc', left:350, top:0, selectable:false});
		if (tagcount >= 2){
			var poly2 = new fabric.Polyline(
				[{x:425, y:100}, {x:475, y:100}, {x:550, y:700}, {x:450, y:700}], {fill:'#bbbbbb', left:425, top:0, selectable:false});
			var poly3 = new fabric.Polyline(
				[{x:325, y:100}, {x:375, y:100}, {x:350, y:700}, {x:250, y:700}], {fill:'#bbbbbb', left:250, top:0, selectable:false});
			canvas.add(poly1, poly2, poly3);
		}
		if (tagcount >= 4){
			var poly4 = new fabric.Polyline(
				[{x:475, y:100}, {x:525, y:100}, {x:650, y:700}, {x:550, y:700}], {fill:'#cccccc', left:475, top:0, selectable:false});
			var poly5 = new fabric.Polyline(
				[{x:275, y:100}, {x:325, y:100}, {x:250, y:700}, {x:150, y:700}], {fill:'#cccccc', left:150, top:0, selectable:false});
			canvas.add(poly4, poly5);
		}
		if (tagcount === 6){
			var poly6 = new fabric.Polyline(
				[{x:525, y:100}, {x:575, y:100}, {x:750, y:700}, {x:650, y:700}], {fill:'#bbbbbb', left:525, top:0, selectable:false});
			var poly7 = new fabric.Polyline(
				[{x:225, y:100}, {x:275, y:100}, {x:150, y:700}, {x:50, y:700}], {fill:'#bbbbbb', left:50, top:0, selectable:false});		     
			canvas.add(poly6, poly7);
			
		}
	  } else {
	    // odd
	  }
	} else {
	  columncount = 8;
    }*/
	
	var newtag;
	var i = 0;
		  newtag = new fabric.Image.fromURL('tlseparator.png', function(img){
			img.scaleToWidth(890).setLeft(125).setTop(650);
			canvas.add(img);
		  });
	while(i < tagcount){
	  (function(idi){
		  newtag = new fabric.Image.fromURL('tlseparator.png', function(img){
			img.scaleToWidth(890).setLeft(125).setTop(575-(75*idi));
			canvas.add(img);
		  });
		  var q = idi + 2;
		  var r = 575-(75*idi);
		  var tagname = $("<div id=\"tag" + q + "\" style=\"position:absolute; height:100px; right:0px; top:"+r+"px; float:right><span style=\"font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + tags[idi] + "</span></div>");
		  $("#activetags").append(tagname);
		  
	  })(i)
	  i++;
    }	
	
	time1 = Math.floor((new Date).getTime()/1000);
	drawTime();
	//constructTags();
	//alert(columncount);
	/*
	switch(columncount){
	  case 1:  $('#otag4').html("Non-tagged"); break;
	  case 2:  $('#etag3').html("Non-tagged");
	             $('#etag4').html(tags[0]); break;
	  case 3:  $('#otag3').html("Non-tagged");
	             $('#otag4').html(tags[0]);
				 $('#otag5').html(tags[1]); break;
	  case 4:  $('#etag3').html("Non-tagged");
	             $('#etag4').html(tags[0]);
				 $('#etag5').html(tags[1]);
				 $('#etag6').html(tags[2]); break;
	  case 5:  $('#otag2').html("Non-tagged");
	             $('#otag3').html(tags[0]);
				 $('#otag4').html(tags[1]);
				 $('#otag5').html(tags[2]);
				 $('#otag6').html(tags[3]); break;
	  case 6:  $('#etag2').html("Non-tagged");
	             $('#etag3').html(tags[0]);
				 $('#etag4').html(tags[1]);
				 $('#e
				 tag5').html(tags[2]);
				 $('#etag6').html(tags[3]); 
				 $('#etag7').html(tags[4]); break;
	  case 7:  $('#otag1').html("Non-tagged");//alert ("test");
	             $('#otag2').html(tags[0]);
				 $('#otag3').html(tags[1]);
				 $('#otag4').html(tags[2]);
				 $('#otag5').html(tags[3]); 
				 $('#otag6').html(tags[4]); 
				 $('#otag7').html(tags[5]); break;
	  case 8:  $('#etag1').html("Non-tagged");
	             $('#etag2').html(tags[0]);
				 $('#etag3').html(tags[1]);
				 $('#etag4').html(tags[2]);
				 $('#etag5').html(tags[3]); 
				 $('#etag6').html(tags[4]); 
				 $('#etag7').html(tags[5]); 
				 $('#etag8').html(tags[6]); break;					 
	
	  
	}*/
	constructPoints();
}

function drawTime(){
  time2 = time1 + timegap;
  /*
  var line1 = new fabric.Polyline(
    [{x:100, y:500}, {x:900, y:500}], {stroke:'black', strokeWidth:3, left:50, top:500, selectable:false});
  var line2 = new fabric.Polyline(
    [{x:165, y:366}, {x:900, y:366}], {stroke:'black', strokeWidth:3, left:115, top:300, selectable:false});
  var line3 = new fabric.Polyline(
    [{x:210, y:233}, {x:900, y:233}], {stroke:'black', strokeWidth:3, left:160, top:150, selectable:false});
  var line4 = new fabric.Polyline(
    [{x:240, y:100}, {x:900, y:100}], {stroke:'black', strokeWidth:3, left:190, top:50, selectable:false});*/
	var a = new Date(time1*1000);
	var b = new Date((time1 + timegap/6)*1000);
	var c = new Date((time1 + 2*timegap/6)*1000);
	var d = new Date((time1 + 3*timegap/6)*1000);
	var e = new Date((time1 + 4*timegap/6)*1000);
	var f = new Date((time1 + 5*timegap/6)*1000);
  var date1 = "" + monthNames[a.getMonth()] + " " + a.getDate() + ", " + a.getFullYear();
  var date2 = "" + monthNames[b.getMonth()] + " " + b.getDate() + ", " + b.getFullYear();
  var date3 = "" + monthNames[c.getMonth()] + " " + c.getDate() + ", " + c.getFullYear();
  var date4 = "" + monthNames[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
  var date5 = "" + monthNames[e.getMonth()] + " " + e.getDate() + ", " + e.getFullYear();
  var date6 = "" + monthNames[f.getMonth()] + " " + f.getDate() + ", " + f.getFullYear();
  
  
  var d1 = $("<div id=\"date\" style=\"position:absolute; text-align:center; height:50px; width:152px; left:132px; top:0px\"><span style=\"display:inline-block; margin:0 auto; font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + date1 + "</span></div>");
  var d2 = $("<div id=\"date\" style=\"position:absolute; text-align:center; height:50px; width:152px; left:280px; top:0px\"><span style=\"display:inline-block; margin:0 auto; font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + date2 + "</span></div>");
  var d3 = $("<div id=\"date\" style=\"position:absolute; text-align:center; height:50px; width:152px; left:431px; top:0px\"><span style=\"display:inline-block; margin:0 auto; font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + date3 + "</span></div>");
  var d4 = $("<div id=\"date\" style=\"position:absolute; text-align:center; height:50px; width:152px; left:579px; top:0px\"><span style=\"display:inline-block; margin:0 auto; font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + date4 + "</span></div>");
  var d5 = $("<div id=\"date\" style=\"position:absolute; text-align:center; height:50px; width:152px; left:730px; top:0px\"><span style=\"display:inline-block; margin:0 auto; font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + date5 + "</span></div>");
  var d6 = $("<div id=\"date\" style=\"position:absolute; text-align:center; height:50px; width:152px; left:877px; top:0px\"><span style=\"display:inline-block; margin:0 auto; font-family: \"HelveticaNeue-Light\", \"Helvetica Neue Light\", \"Helvetica Neue\", Helvetica, Arial, \"Lucida Grande\", sans-serif\">" + date6 + "</span></div>");
  $("#activedates").append(d1, d2, d3, d4, d5, d6);
  /*
  var text1 = new fabric.Text(date1, {left:825, top:500, fontSize:12, fontWeight: 'normal', selectable:false});
  var text2 = new fabric.Text(date2, {left:825, top:300, fontSize:12, fontWeight: 'normal', selectable:false});
  var text3 = new fabric.Text(date3, {left:825, top:150, fontSize:12, fontWeight: 'normal', selectable:false});
  var text4 = new fabric.Text(date4, {left:825, top:50, fontSize:12, fontWeight: 'normal', selectable:false});
  canvas.add(line1, line2, line3, line4, text1, text2, text3, text4);*/
}

function constructTags(){
}

function constructPoints(){
  var startPoints = [];
  var endPoints = [];
  var xpos;
  var ypos;
  var tbr;
  var point;
  var k;
  //alert(commitments);
  $.each(commitments, function(){
    //alert(this);
    if(this.Start_Date > time1 && this.Start_Date < time2){
	  startPoints.push(this);
	}
	if(this.End_Date > time1 && this.End_Date < time2){
	  endPoints.push(this);
	}
  });
  $.each(startPoints, function(){
    //alert(this.Start_Date + "," + time1 + "," + timegap + "," + time2);
	var top = this.Start_Date - time1;
	var bottom = timegap / 3;
	var div = top / bottom;
	//alert (top + "," + bottom + "," + div);
    if (this.Start_Date < (time1 + timegap/3)){
	  ypos = 300+200*((this.Start_Date - time1)/(timegap/3));
	} else if (this.Start_Date < (time1 + (2*timegap)/3)){
	  ypos = 150 + 150*((this.Start_Date - time1 - timegap/3)/(timegap/3));
	} else {
	  ypos = 50 + 100*((this.Start_Date - time1 - (2*timegap)/3)/(timegap/3));
	}
	//alert(this.Tags);
	xpos = 400 - (columncount*25) - (175*(ypos/600));
	//alert (xpos + "," + ypos);
	point = new fabric.Circle({radius:10, fill:'blue', top:ypos, left:xpos, selectable:false});
	//point.on(
	canvas.add(point);
	$.each(this.Tags, function(){
	  if($.inArray(this.toString(), tags)){
	    k = 0.0 + tags.indexOf(this.toString()) - (columncount/2.0);
		xpos = 400 + (200*k);
		point = new fabric.Circle({radius:10, fill:'blue', top:ypos, left:xpos, selectable:false});
		canvas.add(point);
	  }
	});
	//var point = new fabric.Circle({radius:20, fill:'blue',  
  });
}